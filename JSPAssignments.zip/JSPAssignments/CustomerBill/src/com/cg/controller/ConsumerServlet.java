package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Consumer;
import com.cg.dto.ConsumerBill;
import com.cg.service.ConsumerService;
import com.cg.service.ConsumerServiceImpl;

/**
 * Servlet implementation class ConsumerServlet
 */
@WebServlet("/ConsumerServlet")
public class ConsumerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 ConsumerService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsumerServlet() {
        super();
        service=new  ConsumerServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(true);
		String qstr=request.getParameter("action");
		System.out.println("Hellodoget");
		if(qstr.equals("ConsumerList"))
		{
			System.out.println("inside doget if");
			ArrayList<Consumer> list=service.getAllConsumer();
			session.setAttribute("cust", list);
			
			RequestDispatcher dispatch=request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request,  response);
			
		}
		else if(qstr.equals("SearchConsumer"))
		{
			
			RequestDispatcher dispatch=request.getRequestDispatcher("search.jsp");
			dispatch.forward(request,  response);
		}
		else if(qstr.equals("generateBill"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			session.setAttribute("id", id);
			RequestDispatcher dispatch=request.getRequestDispatcher("Bill.jsp");
			dispatch.forward(request,  response);
		}
		else if(qstr.equals("showBill"))
		{
			
			int id1=Integer.parseInt(request.getParameter("id"));
			session.setAttribute("id", id1);
			ArrayList<ConsumerBill> cb=service.getAllBill(id1);
			if(cb!=null)
			{
				System.out.println(cb);
			session.setAttribute("bill", cb);
			RequestDispatcher dispatch=request.getRequestDispatcher("showBill.jsp");
			dispatch.forward(request,  response);
			}
			else
			{
				Consumer c=service.getConsumerById(id1);
				session.setAttribute("name", c);
				RequestDispatcher dispatch=request.getRequestDispatcher("billNotPresent.jsp");
				dispatch.forward(request,  response);
			}
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);
		String qstr=request.getParameter("action");
		if(qstr.equals("searchById"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			Consumer cons=service.getConsumerById(id);
			session.setAttribute("cons", cons);
			RequestDispatcher dispatch=request.getRequestDispatcher("searchSuccess.jsp");
			dispatch.forward(request,  response);
		}
		else if(qstr.equals("insertbill"))
		{
			
			int id=Integer.parseInt(request.getParameter("id"));
			double lmr=Double.parseDouble(request.getParameter("lm"));
			double cmr=Double.parseDouble(request.getParameter("cm"));
			double reading=cmr-lmr;
			System.out.println("reading is"+reading);
			double amt=reading*1.15+100;
			
			ConsumerBill cbill=new ConsumerBill();
			cbill.setConsumer_num(id);
			session.setAttribute("dispId", id);
			cbill.setNetAmount(amt);
			cbill.setCur_reading(cmr);
			cbill.setUnitConsumed(reading);
			System.out.println("yo"+cbill.getUnitConsumed());
			ConsumerBill ref=service.addBill(id, cbill);
			//ArrayList<ConsumerBill> cb=service.getAllBill(id);
			//System.out.println("wfderge"+cb.size());
			Consumer cons=service.getConsumerById(id);
			session.setAttribute("consnames", cons.getConsumer_name());
				System.out.println("helloooooooooooooooooooooo"+ref);
				session.setAttribute("bill", ref);
				RequestDispatcher dispatch =request.getRequestDispatcher("BillCalculated.jsp");
		    	dispatch.forward(request, response);

			
		}
	}

}
