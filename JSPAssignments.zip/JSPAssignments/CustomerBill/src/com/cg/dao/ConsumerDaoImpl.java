package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.dto.Consumer;
import com.cg.dto.ConsumerBill;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class ConsumerDaoImpl implements ConsumerDao
{
	Connection con;
	public ConsumerDaoImpl()
	{
		con=DBUtil.getConnection();
	}

	@Override
	public ArrayList<Consumer> getAllConsumer() 
	{
		String qry="select * from Consumers";
		ArrayList<Consumer> list=new ArrayList<Consumer>();
		try {
			System.out.println("inside try of getAll");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String addr=rs.getString(3);
				Consumer c=new Consumer(id,name,addr);
				list.add(c);
				System.out.println("yes");
			}
			if(list!=null)
			{
				System.out.println("Not null");
			}
			else System.out.println("Null");
			return list;
		} 
		catch (SQLException e) 
		{			
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public Consumer getConsumerById(int id) 
	{
		Consumer cust=null;
		String qry="Select * from Consumers where  consumer_num=?";
		try 
		{	
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setInt(1,id);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				String name=rs.getString(2);
				String addr=rs.getString(3);
				cust=new Consumer(id, name,addr);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return cust;
		
	}

	@Override
	public ConsumerBill addBill(int id, ConsumerBill cbill) 
	{
		 String qry="Insert into BillDetails values(seq_bill_num.nextval,?,?,?,?,sysdate)";
			try
			{
				PreparedStatement pst=con.prepareStatement(qry);
				pst.setInt(1, id);
				pst.setDouble(2, cbill.getCur_reading());
				pst.setDouble(3, cbill.getUnitConsumed());
				pst.setDouble(4, cbill.getNetAmount());
				int row=pst.executeUpdate();
				if(row>0)
				{
					System.out.println("bill added successfully");
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return cbill;
	}

	@Override
	public ArrayList<ConsumerBill> getAllBill(int id) 
	{

		String qry="select * from BillDetails where consumer_num=?";
		ArrayList<ConsumerBill> list=new ArrayList<ConsumerBill>();
		try {
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setInt(1,id);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				int bnum=rs.getInt(1);
				int cid=rs.getInt(2);
				double cr=rs.getDouble(3);
				double cunit=rs.getDouble(4);
				double amt=rs.getDouble(5);
				LocalDate ld=MyStringDateUtil.fromSqlToLocalDate(rs.getDate(6));		
				ConsumerBill cbill=new ConsumerBill(bnum, cid,cr, cunit, amt,ld);
				list.add(cbill);
			}
			
			if(list.size()==0){
				list=null;
			}
		} 
		catch (SQLException e) 
		{		
			e.printStackTrace();
		}
		
		return list;
	}

}
