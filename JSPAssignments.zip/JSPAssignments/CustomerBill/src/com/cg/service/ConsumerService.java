package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Consumer;
import com.cg.dto.ConsumerBill;

public interface ConsumerService 
{
	public ArrayList<Consumer> getAllConsumer();
	public Consumer getConsumerById(int id);
	public ConsumerBill addBill(int id, ConsumerBill cbill);
	public ArrayList<ConsumerBill> getAllBill(int id);
}
