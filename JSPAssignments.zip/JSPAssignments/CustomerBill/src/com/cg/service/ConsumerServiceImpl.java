package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.ConsumerDaoImpl;
import com.cg.dto.Consumer;
import com.cg.dto.ConsumerBill;

public class ConsumerServiceImpl implements ConsumerService
{
	ConsumerDaoImpl dao=new ConsumerDaoImpl();

	@Override
	public ArrayList<Consumer> getAllConsumer() 
	{
		
		return dao.getAllConsumer();
	}

	@Override
	public Consumer getConsumerById(int id) 
	{
		
		return dao.getConsumerById(id);
	}

	@Override
	public ConsumerBill addBill(int id, ConsumerBill cbill) 
	{
		
		return dao.addBill(id, cbill);
	}

	@Override
	public ArrayList<ConsumerBill> getAllBill(int id) 
	{
	
		return dao.getAllBill(id);
	}
	
}
